```python
!pip install XgBoost
!pip install Lightgbm
!pip install imbalanced-learn
!pip install  notebook of pandas
!pip install lifelines
```

    Requirement already satisfied: XgBoost in c:\users\hemanth\anaconda3\lib\site-packages (3.1.2)
    Requirement already satisfied: numpy in c:\users\hemanth\anaconda3\lib\site-packages (from XgBoost) (1.26.4)
    Requirement already satisfied: scipy in c:\users\hemanth\anaconda3\lib\site-packages (from XgBoost) (1.13.1)
    Requirement already satisfied: Lightgbm in c:\users\hemanth\anaconda3\lib\site-packages (4.6.0)
    Requirement already satisfied: numpy>=1.17.0 in c:\users\hemanth\anaconda3\lib\site-packages (from Lightgbm) (1.26.4)
    Requirement already satisfied: scipy in c:\users\hemanth\anaconda3\lib\site-packages (from Lightgbm) (1.13.1)
    Requirement already satisfied: imbalanced-learn in c:\users\hemanth\anaconda3\lib\site-packages (0.12.3)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\hemanth\anaconda3\lib\site-packages (from imbalanced-learn) (1.26.4)
    Requirement already satisfied: scipy>=1.5.0 in c:\users\hemanth\anaconda3\lib\site-packages (from imbalanced-learn) (1.13.1)
    Requirement already satisfied: scikit-learn>=1.0.2 in c:\users\hemanth\anaconda3\lib\site-packages (from imbalanced-learn) (1.4.2)
    Requirement already satisfied: joblib>=1.1.1 in c:\users\hemanth\anaconda3\lib\site-packages (from imbalanced-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\users\hemanth\anaconda3\lib\site-packages (from imbalanced-learn) (2.2.0)
    Requirement already satisfied: notebook in c:\users\hemanth\anaconda3\lib\site-packages (7.0.8)
    Requirement already satisfied: of in c:\users\hemanth\anaconda3\lib\site-packages (1.0.1)
    Requirement already satisfied: pandas in c:\users\hemanth\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: jupyter-server<3,>=2.4.0 in c:\users\hemanth\anaconda3\lib\site-packages (from notebook) (2.14.1)
    Requirement already satisfied: jupyterlab-server<3,>=2.22.1 in c:\users\hemanth\anaconda3\lib\site-packages (from notebook) (2.25.1)
    Requirement already satisfied: jupyterlab<4.1,>=4.0.2 in c:\users\hemanth\anaconda3\lib\site-packages (from notebook) (4.0.11)
    Requirement already satisfied: notebook-shim<0.3,>=0.2 in c:\users\hemanth\anaconda3\lib\site-packages (from notebook) (0.2.3)
    Requirement already satisfied: tornado>=6.2.0 in c:\users\hemanth\anaconda3\lib\site-packages (from notebook) (6.4.1)
    Requirement already satisfied: pymongo in c:\users\hemanth\anaconda3\lib\site-packages (from of) (4.15.5)
    Requirement already satisfied: jsonschema in c:\users\hemanth\anaconda3\lib\site-packages (from of) (4.19.2)
    Requirement already satisfied: decorator in c:\users\hemanth\anaconda3\lib\site-packages (from of) (5.1.1)
    Requirement already satisfied: requests in c:\users\hemanth\anaconda3\lib\site-packages (from of) (2.32.2)
    Requirement already satisfied: cherrypy in c:\users\hemanth\anaconda3\lib\site-packages (from of) (18.10.0)
    Requirement already satisfied: ws4py in c:\users\hemanth\anaconda3\lib\site-packages (from of) (0.6.0)
    Requirement already satisfied: urllib3 in c:\users\hemanth\anaconda3\lib\site-packages (from of) (2.2.2)
    Requirement already satisfied: distlib in c:\users\hemanth\anaconda3\lib\site-packages (from of) (0.4.0)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: anyio>=3.1.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (4.2.0)
    Requirement already satisfied: argon2-cffi>=21.1 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (21.3.0)
    Requirement already satisfied: jinja2>=3.0.3 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (3.1.4)
    Requirement already satisfied: jupyter-client>=7.4.4 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (8.6.0)
    Requirement already satisfied: jupyter-core!=5.0.*,>=4.12 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (5.7.2)
    Requirement already satisfied: jupyter-events>=0.9.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (0.10.0)
    Requirement already satisfied: jupyter-server-terminals>=0.4.4 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (0.4.4)
    Requirement already satisfied: nbconvert>=6.4.4 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (7.10.0)
    Requirement already satisfied: nbformat>=5.3.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (5.9.2)
    Requirement already satisfied: overrides>=5.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (7.4.0)
    Requirement already satisfied: packaging>=22.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (23.2)
    Requirement already satisfied: prometheus-client>=0.9 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (0.14.1)
    Requirement already satisfied: pywinpty>=2.0.1 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (2.0.10)
    Requirement already satisfied: pyzmq>=24 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (25.1.2)
    Requirement already satisfied: send2trash>=1.8.2 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (1.8.2)
    Requirement already satisfied: terminado>=0.8.3 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (0.17.1)
    Requirement already satisfied: traitlets>=5.6.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (5.14.3)
    Requirement already satisfied: websocket-client>=1.7 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-server<3,>=2.4.0->notebook) (1.8.0)
    Requirement already satisfied: async-lru>=1.0.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyterlab<4.1,>=4.0.2->notebook) (2.0.4)
    Requirement already satisfied: ipykernel in c:\users\hemanth\anaconda3\lib\site-packages (from jupyterlab<4.1,>=4.0.2->notebook) (6.28.0)
    Requirement already satisfied: jupyter-lsp>=2.0.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyterlab<4.1,>=4.0.2->notebook) (2.2.0)
    Requirement already satisfied: babel>=2.10 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyterlab-server<3,>=2.22.1->notebook) (2.11.0)
    Requirement already satisfied: json5>=0.9.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyterlab-server<3,>=2.22.1->notebook) (0.9.6)
    Requirement already satisfied: attrs>=22.2.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema->of) (23.1.0)
    Requirement already satisfied: jsonschema-specifications>=2023.03.6 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema->of) (2023.7.1)
    Requirement already satisfied: referencing>=0.28.4 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema->of) (0.30.2)
    Requirement already satisfied: rpds-py>=0.7.1 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema->of) (0.10.6)
    Requirement already satisfied: six>=1.5 in c:\users\hemanth\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\hemanth\anaconda3\lib\site-packages (from requests->of) (2.0.4)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\hemanth\anaconda3\lib\site-packages (from requests->of) (3.7)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\hemanth\anaconda3\lib\site-packages (from requests->of) (2024.7.4)
    Requirement already satisfied: cheroot>=8.2.1 in c:\users\hemanth\anaconda3\lib\site-packages (from cherrypy->of) (11.1.2)
    Requirement already satisfied: portend>=2.1.1 in c:\users\hemanth\anaconda3\lib\site-packages (from cherrypy->of) (3.2.1)
    Requirement already satisfied: more-itertools in c:\users\hemanth\anaconda3\lib\site-packages (from cherrypy->of) (10.1.0)
    Requirement already satisfied: zc.lockfile in c:\users\hemanth\anaconda3\lib\site-packages (from cherrypy->of) (4.0)
    Requirement already satisfied: jaraco.collections in c:\users\hemanth\anaconda3\lib\site-packages (from cherrypy->of) (5.2.1)
    Requirement already satisfied: dnspython<3.0.0,>=1.16.0 in c:\users\hemanth\anaconda3\lib\site-packages (from pymongo->of) (2.8.0)
    Requirement already satisfied: sniffio>=1.1 in c:\users\hemanth\anaconda3\lib\site-packages (from anyio>=3.1.0->jupyter-server<3,>=2.4.0->notebook) (1.3.0)
    Requirement already satisfied: argon2-cffi-bindings in c:\users\hemanth\anaconda3\lib\site-packages (from argon2-cffi>=21.1->jupyter-server<3,>=2.4.0->notebook) (21.2.0)
    Requirement already satisfied: jaraco.functools in c:\users\hemanth\anaconda3\lib\site-packages (from cheroot>=8.2.1->cherrypy->of) (4.4.0)
    Requirement already satisfied: MarkupSafe>=2.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jinja2>=3.0.3->jupyter-server<3,>=2.4.0->notebook) (2.1.3)
    Requirement already satisfied: platformdirs>=2.5 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-core!=5.0.*,>=4.12->jupyter-server<3,>=2.4.0->notebook) (3.10.0)
    Requirement already satisfied: pywin32>=300 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-core!=5.0.*,>=4.12->jupyter-server<3,>=2.4.0->notebook) (305.1)
    Requirement already satisfied: python-json-logger>=2.0.4 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (2.0.7)
    Requirement already satisfied: pyyaml>=5.3 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (6.0.1)
    Requirement already satisfied: rfc3339-validator in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (0.1.4)
    Requirement already satisfied: rfc3986-validator>=0.1.1 in c:\users\hemanth\anaconda3\lib\site-packages (from jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (0.1.1)
    Requirement already satisfied: beautifulsoup4 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (4.12.3)
    Requirement already satisfied: bleach!=5.0.0 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (4.1.0)
    Requirement already satisfied: defusedxml in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (0.7.1)
    Requirement already satisfied: jupyterlab-pygments in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (0.1.2)
    Requirement already satisfied: mistune<4,>=2.0.3 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (2.0.4)
    Requirement already satisfied: nbclient>=0.5.0 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (0.8.0)
    Requirement already satisfied: pandocfilters>=1.4.1 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (1.5.0)
    Requirement already satisfied: pygments>=2.4.1 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (2.15.1)
    Requirement already satisfied: tinycss2 in c:\users\hemanth\anaconda3\lib\site-packages (from nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (1.2.1)
    Requirement already satisfied: fastjsonschema in c:\users\hemanth\anaconda3\lib\site-packages (from nbformat>=5.3.0->jupyter-server<3,>=2.4.0->notebook) (2.16.2)
    Requirement already satisfied: tempora>=1.8 in c:\users\hemanth\anaconda3\lib\site-packages (from portend>=2.1.1->cherrypy->of) (5.8.1)
    Requirement already satisfied: comm>=0.1.1 in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.2.1)
    Requirement already satisfied: debugpy>=1.6.5 in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (1.6.7)
    Requirement already satisfied: ipython>=7.23.1 in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (8.25.0)
    Requirement already satisfied: matplotlib-inline>=0.1 in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.1.6)
    Requirement already satisfied: nest-asyncio in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (1.6.0)
    Requirement already satisfied: psutil in c:\users\hemanth\anaconda3\lib\site-packages (from ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (5.9.0)
    Requirement already satisfied: jaraco.text in c:\users\hemanth\anaconda3\lib\site-packages (from jaraco.collections->cherrypy->of) (4.0.0)
    Requirement already satisfied: setuptools in c:\users\hemanth\anaconda3\lib\site-packages (from zc.lockfile->cherrypy->of) (69.5.1)
    Requirement already satisfied: webencodings in c:\users\hemanth\anaconda3\lib\site-packages (from bleach!=5.0.0->nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (0.5.1)
    Requirement already satisfied: jedi>=0.16 in c:\users\hemanth\anaconda3\lib\site-packages (from ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.18.1)
    Requirement already satisfied: prompt-toolkit<3.1.0,>=3.0.41 in c:\users\hemanth\anaconda3\lib\site-packages (from ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (3.0.43)
    Requirement already satisfied: stack-data in c:\users\hemanth\anaconda3\lib\site-packages (from ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.2.0)
    Requirement already satisfied: colorama in c:\users\hemanth\anaconda3\lib\site-packages (from ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.4.6)
    Requirement already satisfied: fqdn in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (1.5.1)
    Requirement already satisfied: isoduration in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (20.11.0)
    Requirement already satisfied: jsonpointer>1.13 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (2.1)
    Requirement already satisfied: uri-template in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (1.3.0)
    Requirement already satisfied: webcolors>=1.11 in c:\users\hemanth\anaconda3\lib\site-packages (from jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (25.10.0)
    Requirement already satisfied: cffi>=1.0.1 in c:\users\hemanth\anaconda3\lib\site-packages (from argon2-cffi-bindings->argon2-cffi>=21.1->jupyter-server<3,>=2.4.0->notebook) (1.16.0)
    Requirement already satisfied: soupsieve>1.2 in c:\users\hemanth\anaconda3\lib\site-packages (from beautifulsoup4->nbconvert>=6.4.4->jupyter-server<3,>=2.4.0->notebook) (2.5)
    Requirement already satisfied: jaraco.context>=4.1 in c:\users\hemanth\anaconda3\lib\site-packages (from jaraco.text->jaraco.collections->cherrypy->of) (6.0.2)
    Requirement already satisfied: autocommand in c:\users\hemanth\anaconda3\lib\site-packages (from jaraco.text->jaraco.collections->cherrypy->of) (2.2.2)
    Requirement already satisfied: pycparser in c:\users\hemanth\anaconda3\lib\site-packages (from cffi>=1.0.1->argon2-cffi-bindings->argon2-cffi>=21.1->jupyter-server<3,>=2.4.0->notebook) (2.21)
    Requirement already satisfied: parso<0.9.0,>=0.8.0 in c:\users\hemanth\anaconda3\lib\site-packages (from jedi>=0.16->ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.8.3)
    Requirement already satisfied: wcwidth in c:\users\hemanth\anaconda3\lib\site-packages (from prompt-toolkit<3.1.0,>=3.0.41->ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.2.5)
    Requirement already satisfied: arrow>=0.15.0 in c:\users\hemanth\anaconda3\lib\site-packages (from isoduration->jsonschema[format-nongpl]>=4.18.0->jupyter-events>=0.9.0->jupyter-server<3,>=2.4.0->notebook) (1.2.3)
    Requirement already satisfied: executing in c:\users\hemanth\anaconda3\lib\site-packages (from stack-data->ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.8.3)
    Requirement already satisfied: asttokens in c:\users\hemanth\anaconda3\lib\site-packages (from stack-data->ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (2.0.5)
    Requirement already satisfied: pure-eval in c:\users\hemanth\anaconda3\lib\site-packages (from stack-data->ipython>=7.23.1->ipykernel->jupyterlab<4.1,>=4.0.2->notebook) (0.2.2)
    Collecting lifelines
      Downloading lifelines-0.30.0-py3-none-any.whl.metadata (3.2 kB)
    Requirement already satisfied: numpy>=1.14.0 in c:\users\hemanth\anaconda3\lib\site-packages (from lifelines) (1.26.4)
    Requirement already satisfied: scipy>=1.7.0 in c:\users\hemanth\anaconda3\lib\site-packages (from lifelines) (1.13.1)
    Requirement already satisfied: pandas>=2.1 in c:\users\hemanth\anaconda3\lib\site-packages (from lifelines) (2.2.2)
    Requirement already satisfied: matplotlib>=3.0 in c:\users\hemanth\anaconda3\lib\site-packages (from lifelines) (3.8.4)
    Collecting autograd>=1.5 (from lifelines)
      Downloading autograd-1.8.0-py3-none-any.whl.metadata (7.5 kB)
    Collecting autograd-gamma>=0.3 (from lifelines)
      Downloading autograd-gamma-0.5.0.tar.gz (4.0 kB)
      Preparing metadata (setup.py): started
      Preparing metadata (setup.py): finished with status 'done'
    Collecting formulaic>=0.2.2 (from lifelines)
      Downloading formulaic-1.2.1-py3-none-any.whl.metadata (7.0 kB)
    Collecting interface-meta>=1.2.0 (from formulaic>=0.2.2->lifelines)
      Downloading interface_meta-1.3.0-py3-none-any.whl.metadata (6.7 kB)
    Collecting narwhals>=1.17 (from formulaic>=0.2.2->lifelines)
      Downloading narwhals-2.14.0-py3-none-any.whl.metadata (13 kB)
    Requirement already satisfied: typing-extensions>=4.2.0 in c:\users\hemanth\anaconda3\lib\site-packages (from formulaic>=0.2.2->lifelines) (4.11.0)
    Requirement already satisfied: wrapt>=1.0 in c:\users\hemanth\anaconda3\lib\site-packages (from formulaic>=0.2.2->lifelines) (1.14.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (23.2)
    Requirement already satisfied: pillow>=8 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (10.3.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\hemanth\anaconda3\lib\site-packages (from matplotlib>=3.0->lifelines) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas>=2.1->lifelines) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\hemanth\anaconda3\lib\site-packages (from pandas>=2.1->lifelines) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\hemanth\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib>=3.0->lifelines) (1.16.0)
    Downloading lifelines-0.30.0-py3-none-any.whl (349 kB)
       ---------------------------------------- 0.0/349.3 kB ? eta -:--:--
       ---------------------------------------- 0.0/349.3 kB ? eta -:--:--
       - -------------------------------------- 10.2/349.3 kB ? eta -:--:--
       --- ----------------------------------- 30.7/349.3 kB 435.7 kB/s eta 0:00:01
       ------ -------------------------------- 61.4/349.3 kB 409.6 kB/s eta 0:00:01
       ---------- ---------------------------- 92.2/349.3 kB 476.3 kB/s eta 0:00:01
       ----------- -------------------------- 102.4/349.3 kB 454.0 kB/s eta 0:00:01
       --------------- ---------------------- 143.4/349.3 kB 500.5 kB/s eta 0:00:01
       ---------------- --------------------- 153.6/349.3 kB 482.7 kB/s eta 0:00:01
       ------------------ ------------------- 174.1/349.3 kB 499.5 kB/s eta 0:00:01
       ------------------ ------------------- 174.1/349.3 kB 499.5 kB/s eta 0:00:01
       ------------------ ------------------- 174.1/349.3 kB 499.5 kB/s eta 0:00:01
       ---------------------- --------------- 204.8/349.3 kB 414.8 kB/s eta 0:00:01
       ------------------------ ------------- 225.3/349.3 kB 405.0 kB/s eta 0:00:01
       ------------------------- ------------ 235.5/349.3 kB 389.8 kB/s eta 0:00:01
       ------------------------- ------------ 235.5/349.3 kB 389.8 kB/s eta 0:00:01
       ------------------------- ------------ 235.5/349.3 kB 389.8 kB/s eta 0:00:01
       ---------------------------- --------- 266.2/349.3 kB 364.2 kB/s eta 0:00:01
       ------------------------------- ------ 286.7/349.3 kB 360.9 kB/s eta 0:00:01
       ------------------------------- ------ 286.7/349.3 kB 360.9 kB/s eta 0:00:01
       ------------------------------- ------ 286.7/349.3 kB 360.9 kB/s eta 0:00:01
       ---------------------------------- --- 317.4/349.3 kB 339.1 kB/s eta 0:00:01
       ---------------------------------- --- 317.4/349.3 kB 339.1 kB/s eta 0:00:01
       -------------------------------------  348.2/349.3 kB 337.9 kB/s eta 0:00:01
       -------------------------------------- 349.3/349.3 kB 328.9 kB/s eta 0:00:00
    Downloading autograd-1.8.0-py3-none-any.whl (51 kB)
       ---------------------------------------- 0.0/51.5 kB ? eta -:--:--
       ---------------------------------------- 0.0/51.5 kB ? eta -:--:--
       ------- -------------------------------- 10.2/51.5 kB ? eta -:--:--
       ------- -------------------------------- 10.2/51.5 kB ? eta -:--:--
       ---------------------------------------- 51.5/51.5 kB 443.4 kB/s eta 0:00:00
    Downloading formulaic-1.2.1-py3-none-any.whl (117 kB)
       ---------------------------------------- 0.0/117.3 kB ? eta -:--:--
       --- ------------------------------------ 10.2/117.3 kB ? eta -:--:--
       ---------- ---------------------------- 30.7/117.3 kB 435.7 kB/s eta 0:00:01
       ------------- ------------------------- 41.0/117.3 kB 281.8 kB/s eta 0:00:01
       ----------------------- --------------- 71.7/117.3 kB 357.2 kB/s eta 0:00:01
       ------------------------------ -------- 92.2/117.3 kB 403.5 kB/s eta 0:00:01
       -------------------------------------- 117.3/117.3 kB 404.0 kB/s eta 0:00:00
    Downloading interface_meta-1.3.0-py3-none-any.whl (14 kB)
    Downloading narwhals-2.14.0-py3-none-any.whl (430 kB)
       ---------------------------------------- 0.0/430.8 kB ? eta -:--:--
        --------------------------------------- 10.2/430.8 kB ? eta -:--:--
       --- ----------------------------------- 41.0/430.8 kB 487.6 kB/s eta 0:00:01
       ----- --------------------------------- 61.4/430.8 kB 465.5 kB/s eta 0:00:01
       -------- ------------------------------ 92.2/430.8 kB 525.1 kB/s eta 0:00:01
       --------- ---------------------------- 102.4/430.8 kB 454.0 kB/s eta 0:00:01
       ---------- --------------------------- 122.9/430.8 kB 479.3 kB/s eta 0:00:01
       ------------ ------------------------- 143.4/430.8 kB 425.3 kB/s eta 0:00:01
       --------------- ---------------------- 174.1/430.8 kB 499.5 kB/s eta 0:00:01
       ---------------- --------------------- 184.3/430.8 kB 464.2 kB/s eta 0:00:01
       ------------------ ------------------- 215.0/430.8 kB 467.6 kB/s eta 0:00:01
       -------------------- ----------------- 235.5/430.8 kB 480.3 kB/s eta 0:00:01
       ----------------------- -------------- 266.2/430.8 kB 482.1 kB/s eta 0:00:01
       ------------------------- ------------ 286.7/430.8 kB 478.3 kB/s eta 0:00:01
       ---------------------------- --------- 317.4/430.8 kB 491.5 kB/s eta 0:00:01
       ---------------------------- --------- 317.4/430.8 kB 491.5 kB/s eta 0:00:01
       ---------------------------- --------- 317.4/430.8 kB 491.5 kB/s eta 0:00:01
       ---------------------------- --------- 317.4/430.8 kB 491.5 kB/s eta 0:00:01
       ---------------------------- --------- 317.4/430.8 kB 491.5 kB/s eta 0:00:01
       -------------------------------- ----- 368.6/430.8 kB 416.7 kB/s eta 0:00:01
       --------------------------------- ---- 378.9/430.8 kB 406.9 kB/s eta 0:00:01
       --------------------------------- ---- 378.9/430.8 kB 406.9 kB/s eta 0:00:01
       ----------------------------------- -- 399.4/430.8 kB 401.6 kB/s eta 0:00:01
       -------------------------------------  419.8/430.8 kB 397.3 kB/s eta 0:00:01
       -------------------------------------- 430.8/430.8 kB 384.4 kB/s eta 0:00:00
    Building wheels for collected packages: autograd-gamma
      Building wheel for autograd-gamma (setup.py): started
      Building wheel for autograd-gamma (setup.py): finished with status 'done'
      Created wheel for autograd-gamma: filename=autograd_gamma-0.5.0-py3-none-any.whl size=4050 sha256=d47be753f6ffff621c96d0c998e777d5ac1b425dfd1526dd54235170cc1cfa5d
      Stored in directory: c:\users\hemanth\appdata\local\pip\cache\wheels\50\37\21\0a719b9d89c635e89ff24bd93b862882ad675279552013b2fb
    Successfully built autograd-gamma
    Installing collected packages: narwhals, interface-meta, autograd, autograd-gamma, formulaic, lifelines
    Successfully installed autograd-1.8.0 autograd-gamma-0.5.0 formulaic-1.2.1 interface-meta-1.3.0 lifelines-0.30.0 narwhals-2.14.0
    


```python
#core libraries 
import pandas as pd
import numpy as np
#viualizations
import matplotlib.pyplot as plt
import seaborn as sns
#PreProcessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder,StandardScaler
#models
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
#metrics
from sklearn.metrics import (accuracy_score,confusion_matrix,classification_report,roc_auc_score,roc_curve)
#warnings
import warnings
warnings.filterwarnings('ignore')
```


```python
#loading Datasets
train_df = pd.read_csv(r"C:\Users\Hemanth\Downloads\aug_train.csv")
test_df=pd.read_csv(r"C:\Users\Hemanth\Downloads\aug_test.csv")

print(train_df.shape)
print(test_df.shape)
df=train_df.copy()
df=train_df.shape
```

    (19158, 14)
    (2129, 13)
    


```python
print(train_df.head)
print(test_df.head)
```

    <bound method NDFrame.head of        enrollee_id      city  city_development_index gender  \
    0             8949  city_103                   0.920   Male   
    1            29725   city_40                   0.776   Male   
    2            11561   city_21                   0.624    NaN   
    3            33241  city_115                   0.789    NaN   
    4              666  city_162                   0.767   Male   
    ...            ...       ...                     ...    ...   
    19153         7386  city_173                   0.878   Male   
    19154        31398  city_103                   0.920   Male   
    19155        24576  city_103                   0.920   Male   
    19156         5756   city_65                   0.802   Male   
    19157        23834   city_67                   0.855    NaN   
    
               relevent_experience enrolled_university education_level  \
    0      Has relevent experience       no_enrollment        Graduate   
    1       No relevent experience       no_enrollment        Graduate   
    2       No relevent experience    Full time course        Graduate   
    3       No relevent experience                 NaN        Graduate   
    4      Has relevent experience       no_enrollment         Masters   
    ...                        ...                 ...             ...   
    19153   No relevent experience       no_enrollment        Graduate   
    19154  Has relevent experience       no_enrollment        Graduate   
    19155  Has relevent experience       no_enrollment        Graduate   
    19156  Has relevent experience       no_enrollment     High School   
    19157   No relevent experience       no_enrollment  Primary School   
    
          major_discipline experience company_size    company_type last_new_job  \
    0                 STEM        >20          NaN             NaN            1   
    1                 STEM         15        50-99         Pvt Ltd           >4   
    2                 STEM          5          NaN             NaN        never   
    3      Business Degree         <1          NaN         Pvt Ltd        never   
    4                 STEM        >20        50-99  Funded Startup            4   
    ...                ...        ...          ...             ...          ...   
    19153       Humanities         14          NaN             NaN            1   
    19154             STEM         14          NaN             NaN            4   
    19155             STEM        >20        50-99         Pvt Ltd            4   
    19156              NaN         <1      500-999         Pvt Ltd            2   
    19157              NaN          2          NaN             NaN            1   
    
           training_hours  target  
    0                  36     1.0  
    1                  47     0.0  
    2                  83     0.0  
    3                  52     1.0  
    4                   8     0.0  
    ...               ...     ...  
    19153              42     1.0  
    19154              52     1.0  
    19155              44     0.0  
    19156              97     0.0  
    19157             127     0.0  
    
    [19158 rows x 14 columns]>
    <bound method NDFrame.head of       enrollee_id      city  city_development_index  gender  \
    0           32403   city_41                   0.827    Male   
    1            9858  city_103                   0.920  Female   
    2           31806   city_21                   0.624    Male   
    3           27385   city_13                   0.827    Male   
    4           27724  city_103                   0.920    Male   
    ...           ...       ...                     ...     ...   
    2124         1289  city_103                   0.920    Male   
    2125          195  city_136                   0.897    Male   
    2126        31762  city_100                   0.887    Male   
    2127         7873  city_102                   0.804    Male   
    2128        12215  city_102                   0.804    Male   
    
              relevent_experience enrolled_university education_level  \
    0     Has relevent experience    Full time course        Graduate   
    1     Has relevent experience       no_enrollment        Graduate   
    2      No relevent experience       no_enrollment     High School   
    3     Has relevent experience       no_enrollment         Masters   
    4     Has relevent experience       no_enrollment        Graduate   
    ...                       ...                 ...             ...   
    2124   No relevent experience       no_enrollment        Graduate   
    2125  Has relevent experience       no_enrollment         Masters   
    2126   No relevent experience       no_enrollment  Primary School   
    2127  Has relevent experience    Full time course     High School   
    2128  Has relevent experience       no_enrollment         Masters   
    
         major_discipline experience company_size   company_type last_new_job  \
    0                STEM          9          <10            NaN            1   
    1                STEM          5          NaN        Pvt Ltd            1   
    2                 NaN         <1          NaN        Pvt Ltd        never   
    3                STEM         11        10/49        Pvt Ltd            1   
    4                STEM        >20       10000+        Pvt Ltd           >4   
    ...               ...        ...          ...            ...          ...   
    2124       Humanities         16          NaN  Public Sector            4   
    2125             STEM         18          NaN            NaN            2   
    2126              NaN          3          NaN        Pvt Ltd        never   
    2127              NaN          7      100-500  Public Sector            1   
    2128             STEM         15       10000+        Pvt Ltd            2   
    
          training_hours  
    0                 21  
    1                 98  
    2                 15  
    3                 39  
    4                 72  
    ...              ...  
    2124              15  
    2125              30  
    2126              18  
    2127              84  
    2128              11  
    
    [2129 rows x 13 columns]>
    


```python
print(train_df.describe)
print(test_df.describe)
```

    <bound method NDFrame.describe of        enrollee_id      city  city_development_index gender  \
    0             8949  city_103                   0.920   Male   
    1            29725   city_40                   0.776   Male   
    2            11561   city_21                   0.624    NaN   
    3            33241  city_115                   0.789    NaN   
    4              666  city_162                   0.767   Male   
    ...            ...       ...                     ...    ...   
    19153         7386  city_173                   0.878   Male   
    19154        31398  city_103                   0.920   Male   
    19155        24576  city_103                   0.920   Male   
    19156         5756   city_65                   0.802   Male   
    19157        23834   city_67                   0.855    NaN   
    
               relevent_experience enrolled_university education_level  \
    0      Has relevent experience       no_enrollment        Graduate   
    1       No relevent experience       no_enrollment        Graduate   
    2       No relevent experience    Full time course        Graduate   
    3       No relevent experience                 NaN        Graduate   
    4      Has relevent experience       no_enrollment         Masters   
    ...                        ...                 ...             ...   
    19153   No relevent experience       no_enrollment        Graduate   
    19154  Has relevent experience       no_enrollment        Graduate   
    19155  Has relevent experience       no_enrollment        Graduate   
    19156  Has relevent experience       no_enrollment     High School   
    19157   No relevent experience       no_enrollment  Primary School   
    
          major_discipline experience company_size    company_type last_new_job  \
    0                 STEM        >20          NaN             NaN            1   
    1                 STEM         15        50-99         Pvt Ltd           >4   
    2                 STEM          5          NaN             NaN        never   
    3      Business Degree         <1          NaN         Pvt Ltd        never   
    4                 STEM        >20        50-99  Funded Startup            4   
    ...                ...        ...          ...             ...          ...   
    19153       Humanities         14          NaN             NaN            1   
    19154             STEM         14          NaN             NaN            4   
    19155             STEM        >20        50-99         Pvt Ltd            4   
    19156              NaN         <1      500-999         Pvt Ltd            2   
    19157              NaN          2          NaN             NaN            1   
    
           training_hours  target  
    0                  36     1.0  
    1                  47     0.0  
    2                  83     0.0  
    3                  52     1.0  
    4                   8     0.0  
    ...               ...     ...  
    19153              42     1.0  
    19154              52     1.0  
    19155              44     0.0  
    19156              97     0.0  
    19157             127     0.0  
    
    [19158 rows x 14 columns]>
    <bound method NDFrame.describe of       enrollee_id      city  city_development_index  gender  \
    0           32403   city_41                   0.827    Male   
    1            9858  city_103                   0.920  Female   
    2           31806   city_21                   0.624    Male   
    3           27385   city_13                   0.827    Male   
    4           27724  city_103                   0.920    Male   
    ...           ...       ...                     ...     ...   
    2124         1289  city_103                   0.920    Male   
    2125          195  city_136                   0.897    Male   
    2126        31762  city_100                   0.887    Male   
    2127         7873  city_102                   0.804    Male   
    2128        12215  city_102                   0.804    Male   
    
              relevent_experience enrolled_university education_level  \
    0     Has relevent experience    Full time course        Graduate   
    1     Has relevent experience       no_enrollment        Graduate   
    2      No relevent experience       no_enrollment     High School   
    3     Has relevent experience       no_enrollment         Masters   
    4     Has relevent experience       no_enrollment        Graduate   
    ...                       ...                 ...             ...   
    2124   No relevent experience       no_enrollment        Graduate   
    2125  Has relevent experience       no_enrollment         Masters   
    2126   No relevent experience       no_enrollment  Primary School   
    2127  Has relevent experience    Full time course     High School   
    2128  Has relevent experience       no_enrollment         Masters   
    
         major_discipline experience company_size   company_type last_new_job  \
    0                STEM          9          <10            NaN            1   
    1                STEM          5          NaN        Pvt Ltd            1   
    2                 NaN         <1          NaN        Pvt Ltd        never   
    3                STEM         11        10/49        Pvt Ltd            1   
    4                STEM        >20       10000+        Pvt Ltd           >4   
    ...               ...        ...          ...            ...          ...   
    2124       Humanities         16          NaN  Public Sector            4   
    2125             STEM         18          NaN            NaN            2   
    2126              NaN          3          NaN        Pvt Ltd        never   
    2127              NaN          7      100-500  Public Sector            1   
    2128             STEM         15       10000+        Pvt Ltd            2   
    
          training_hours  
    0                 21  
    1                 98  
    2                 15  
    3                 39  
    4                 72  
    ...              ...  
    2124              15  
    2125              30  
    2126              18  
    2127              84  
    2128              11  
    
    [2129 rows x 13 columns]>
    


```python
train_df.isnull().sum()
test_df.isnull().sum()
```




    enrollee_id                 0
    city                        0
    city_development_index      0
    gender                    508
    relevent_experience         0
    enrolled_university        31
    education_level            52
    major_discipline          312
    experience                  5
    company_size              622
    company_type              634
    last_new_job               40
    training_hours              0
    dtype: int64




```python
print(train_df.info)
print(test_df.info)
```

    <bound method DataFrame.info of        enrollee_id      city  city_development_index gender  \
    0             8949  city_103                   0.920   Male   
    1            29725   city_40                   0.776   Male   
    2            11561   city_21                   0.624    NaN   
    3            33241  city_115                   0.789    NaN   
    4              666  city_162                   0.767   Male   
    ...            ...       ...                     ...    ...   
    19153         7386  city_173                   0.878   Male   
    19154        31398  city_103                   0.920   Male   
    19155        24576  city_103                   0.920   Male   
    19156         5756   city_65                   0.802   Male   
    19157        23834   city_67                   0.855    NaN   
    
               relevent_experience enrolled_university education_level  \
    0      Has relevent experience       no_enrollment        Graduate   
    1       No relevent experience       no_enrollment        Graduate   
    2       No relevent experience    Full time course        Graduate   
    3       No relevent experience                 NaN        Graduate   
    4      Has relevent experience       no_enrollment         Masters   
    ...                        ...                 ...             ...   
    19153   No relevent experience       no_enrollment        Graduate   
    19154  Has relevent experience       no_enrollment        Graduate   
    19155  Has relevent experience       no_enrollment        Graduate   
    19156  Has relevent experience       no_enrollment     High School   
    19157   No relevent experience       no_enrollment  Primary School   
    
          major_discipline experience company_size    company_type last_new_job  \
    0                 STEM        >20          NaN             NaN            1   
    1                 STEM         15        50-99         Pvt Ltd           >4   
    2                 STEM          5          NaN             NaN        never   
    3      Business Degree         <1          NaN         Pvt Ltd        never   
    4                 STEM        >20        50-99  Funded Startup            4   
    ...                ...        ...          ...             ...          ...   
    19153       Humanities         14          NaN             NaN            1   
    19154             STEM         14          NaN             NaN            4   
    19155             STEM        >20        50-99         Pvt Ltd            4   
    19156              NaN         <1      500-999         Pvt Ltd            2   
    19157              NaN          2          NaN             NaN            1   
    
           training_hours  target  
    0                  36     1.0  
    1                  47     0.0  
    2                  83     0.0  
    3                  52     1.0  
    4                   8     0.0  
    ...               ...     ...  
    19153              42     1.0  
    19154              52     1.0  
    19155              44     0.0  
    19156              97     0.0  
    19157             127     0.0  
    
    [19158 rows x 14 columns]>
    <bound method DataFrame.info of       enrollee_id      city  city_development_index  gender  \
    0           32403   city_41                   0.827    Male   
    1            9858  city_103                   0.920  Female   
    2           31806   city_21                   0.624    Male   
    3           27385   city_13                   0.827    Male   
    4           27724  city_103                   0.920    Male   
    ...           ...       ...                     ...     ...   
    2124         1289  city_103                   0.920    Male   
    2125          195  city_136                   0.897    Male   
    2126        31762  city_100                   0.887    Male   
    2127         7873  city_102                   0.804    Male   
    2128        12215  city_102                   0.804    Male   
    
              relevent_experience enrolled_university education_level  \
    0     Has relevent experience    Full time course        Graduate   
    1     Has relevent experience       no_enrollment        Graduate   
    2      No relevent experience       no_enrollment     High School   
    3     Has relevent experience       no_enrollment         Masters   
    4     Has relevent experience       no_enrollment        Graduate   
    ...                       ...                 ...             ...   
    2124   No relevent experience       no_enrollment        Graduate   
    2125  Has relevent experience       no_enrollment         Masters   
    2126   No relevent experience       no_enrollment  Primary School   
    2127  Has relevent experience    Full time course     High School   
    2128  Has relevent experience       no_enrollment         Masters   
    
         major_discipline experience company_size   company_type last_new_job  \
    0                STEM          9          <10            NaN            1   
    1                STEM          5          NaN        Pvt Ltd            1   
    2                 NaN         <1          NaN        Pvt Ltd        never   
    3                STEM         11        10/49        Pvt Ltd            1   
    4                STEM        >20       10000+        Pvt Ltd           >4   
    ...               ...        ...          ...            ...          ...   
    2124       Humanities         16          NaN  Public Sector            4   
    2125             STEM         18          NaN            NaN            2   
    2126              NaN          3          NaN        Pvt Ltd        never   
    2127              NaN          7      100-500  Public Sector            1   
    2128             STEM         15       10000+        Pvt Ltd            2   
    
          training_hours  
    0                 21  
    1                 98  
    2                 15  
    3                 39  
    4                 72  
    ...              ...  
    2124              15  
    2125              30  
    2126              18  
    2127              84  
    2128              11  
    
    [2129 rows x 13 columns]>
    


```python
#Exploratory Data Analysis
train_df.columns=train_df.columns.str.strip()
test_df.columns=test_df.columns.str.strip()
print(train_df.columns.tolist())
print(train_df['target'].value_counts())
```

    ['enrollee_id', 'city', 'city_development_index', 'gender', 'relevent_experience', 'enrolled_university', 'education_level', 'major_discipline', 'experience', 'company_size', 'company_type', 'last_new_job', 'training_hours', 'target']
    target
    0.0    14381
    1.0     4777
    Name: count, dtype: int64
    


```python
type(df)
df=train_df.copy()
```


```python
plt.figure(figsize=(5,4))
ax = sns.countplot(x='target', data=train_df)

# Calculate total count
total = len(train_df)

# Add percentage labels
for p in ax.patches:
    count = p.get_height()
    percentage = (count / total) * 100
    ax.annotate(f'{percentage:.1f}%', 
                (p.get_x() + p.get_width() / 2., count),
                ha='center', va='bottom')

plt.title("Univariate Analysis: Employee Attrition Distribution")
plt.xlabel("Target (0 = Stay, 1 = Leave)")
plt.ylabel("Number of Employees")
plt.show()

```


    
![png](output_9_0.png)
    



```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(6,4))
sns.boxplot(
    x='target',
    y='training_hours',
    data=train_df
)
plt.title("Bivariate Analysis: Training Hours vs Employee Attrition")
plt.xlabel("Target (0 = Stay, 1 = Leave)")
plt.ylabel("Training Hours")
plt.show()

```


    
![png](output_10_0.png)
    



```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(6,4))
ax = sns.countplot(x='target', data=df)

# Total observations
total = len(df)

# Add percentage on top of bars
for p in ax.patches:
    count = p.get_height()
    percentage = (count / total) * 100
    ax.annotate(f'{percentage:.1f}%',
                (p.get_x() + p.get_width()/2., count),
                ha='center', va='bottom')

plt.title("Job Change Distribution")
plt.xlabel("Target (0 = Stay, 1 = Leave)")
plt.ylabel("Number of Employees")
plt.show

```




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_11_1.png)
    



```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(5,4))
ax = sns.countplot(x='target', data=train_df)

total = len(train_df)

for p in ax.patches:
    count = p.get_height()
    percentage = (count / total) * 100
    ax.annotate(f'{percentage:.2f}%',
                (p.get_x() + p.get_width()/2., count/2),
                ha='center', va='center',
                color='white', fontsize=11)

plt.title("Employee Attrition Distribution")
plt.xlabel("Target (0 = Stay, 1 = Leave)")
plt.ylabel("Number of Employees")
plt.show()

```


    
![png](output_12_0.png)
    



```python
print(train_df.shape)
print(train_df.columns)
```

    (19158, 14)
    Index(['enrollee_id', 'city', 'city_development_index', 'gender',
           'relevent_experience', 'enrolled_university', 'education_level',
           'major_discipline', 'experience', 'company_size', 'company_type',
           'last_new_job', 'training_hours', 'target'],
          dtype='object')
    


```python
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Select numerical columns
num_df = train_df.select_dtypes(include=['int64', 'float64'])

# Correlation matrix
corr = num_df.corr()

# Mask for upper triangle
mask = np.triu(np.ones_like(corr, dtype=bool))

plt.figure(figsize=(14,7))
sns.heatmap(corr, mask=mask, annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap (Numerical Features)")
plt.show()

```


    
![png](output_14_0.png)
    



```python
#feature engineering
# Experience
df['experience'] = df['experience'].replace({'<1':0, '>20':21, 'Unknown':None})
df['experience'] = df['experience'].astype(float)
df['experience'].fillna(df['experience'].median(), inplace=True)

# Last new job
df['last_new_job'] = df['last_new_job'].replace({'never':0, '>4':5, 'Unknown':None})
df['last_new_job'] = df['last_new_job'].astype(float)
df['last_new_job'].fillna(df['last_new_job'].median(), inplace=True)

# New feature
df['training_per_experience'] = df['training_hours'] / (df['experience'] + 1)

```


```python
#Data cleaning and Preprocessing
target_col='LeaveOrNot'

for col in train_df.columns:
    #skip target column
    if col== target_col:
     continue 

#handle categorical columns
if train_df[col].dtype=='object':
    mode_value=train_df[col].mode()[0]
    train_df[col].fillna(mode_value,inplace=True)
    
#only fill in test_df if columns exists
if col in test_df.columns:
    test_df[col].fillna(mode_value,inplace=True)

#Handle numerical columns 
else:
    median_value=train_df[col].median()
    train_df[col].fillna(median_value,inplace=True)

#only fill in test_df if column exists
if col in test_df.columns:
   test_df[col].fillna(median_value,inplace=True)

    
    
    
```


```python
#encoding categorical import matplotlib.pyplot as plt
import seaborn as sns

missing = df.isnull().sum()
missing = missing[missing > 0]

plt.figure(figsize=(10,5))
sns.barplot(
    x=missing.index,
    y=missing.values
)
plt.title("Missing Values Count per Feature")
plt.xlabel("Features")
plt.ylabel("Number of Missing Values")
plt.xticks(rotation=45)
plt.show()

from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
cat_cols=train_df.select_dtypes(include='object').columns
for col in cat_cols:
    train_df[col]=le.fit_transform(train_df[col])
    test_df[col]=le.transform(test_df[col])
```


    
![png](output_17_0.png)
    



```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

num_cols = train_df.drop(columns=['target']).select_dtypes(include=['int64','float64']).columns

train_df[num_cols] = scaler.fit_transform(train_df[num_cols])

```


```python
#Feature and Target split
#Identifying Column Types
y = train_df['target']
X = train_df.drop('target', axis=1)
cat_cols = X.select_dtypes(include='object').columns
num_cols = X.select_dtypes(exclude='object').columns



```


```python
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer

preprocessor = ColumnTransformer(
    transformers=[
        ('num', 'passthrough', num_cols),
        ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols)
    ]
)

```


```python
y = df['target']
X = df.drop(columns=['target'])

```


```python
# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)


```


```python
num_cols = X_train.select_dtypes(include=['int64', 'float64']).columns
cat_cols = X_train.select_dtypes(include=['object']).columns

```


```python
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder

# Identify columns
num_cols = X_train.select_dtypes(include=['int64', 'float64']).columns.tolist()
cat_cols = X_train.select_dtypes(include=['object']).columns.tolist()

# Build preprocessor CLEANLY
preprocessor = ColumnTransformer(
    transformers=[
        ('num', 'passthrough', num_cols),
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), cat_cols)
    ]
)

```


```python
# Encode

X_train_enc= preprocessor.fit_transform(X_train)
X_test_enc= preprocessor.transform(X_test)

# SMOTE
from imblearn.over_sampling import SMOTE
smote = SMOTE(random_state=42)
X_train_sm, y_train_sm = smote.fit_resample(X_train_enc, y_train)

```


```python
X_train_enc = preprocessor.fit_transform(X_train)
X_test_enc  = preprocessor.transform(X_test)

```


```python
from imblearn.over_sampling import SMOTE

smote = SMOTE(random_state=42)
X_train_sm, y_train_sm = smote.fit_resample(X_train_enc, y_train)

```


```python
print("before SMOTE:\n",y_train.value_counts())
print("\nafter SMOTE:\n",y_train_sm.value_counts())
```

    before SMOTE:
     target
    0.0    11504
    1.0     3822
    Name: count, dtype: int64
    
    after SMOTE:
     target
    0.0    11504
    1.0    11504
    Name: count, dtype: int64
    


```python
from sklearn.metrics import accuracy_score, roc_auc_score

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:,1]
    return {
        "Accuracy": accuracy_score(y_test, y_pred),
        "ROC-AUC": roc_auc_score(y_test, y_prob)
    }

```


```python
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Logistic Regression
lr = LogisticRegression(max_iter=1000)

# Train on SMOTE data
lr.fit(X_train_sm, y_train_sm)

# Predict on encoded test data
y_pred_lr = lr.predict(X_test_enc)

print("Accuracy:", accuracy_score(y_test, y_pred_lr))

```

    Accuracy: 0.7716597077244259
    


```python
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

rf = RandomForestClassifier(
    n_estimators=200,
    random_state=42
)

rf.fit(X_train_sm, y_train_sm)

y_pred_rf = rf.predict(X_test_enc)
print("Accuracy:", accuracy_score(y_test, y_pred_rf))

```

    Accuracy: 0.785490605427975
    


```python
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, classification_report

xgb = XGBClassifier(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    eval_metric='logloss',
    random_state=42
)

xgb.fit(X_train_sm, y_train_sm)

y_pred_xgb = xgb.predict(X_test_enc)

print("XGBoost Accuracy:", accuracy_score(y_test, y_pred_xgb))
print(classification_report(y_test, y_pred_xgb))

```

    XGBoost Accuracy: 0.7993215031315241
                  precision    recall  f1-score   support
    
             0.0       0.87      0.86      0.87      2877
             1.0       0.60      0.61      0.60       955
    
        accuracy                           0.80      3832
       macro avg       0.73      0.73      0.73      3832
    weighted avg       0.80      0.80      0.80      3832
    
    


```python
from lightgbm import LGBMClassifier

lgbm = LGBMClassifier(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=-1,
    num_leaves=31,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)

lgbm.fit(X_train_sm, y_train_sm)

y_pred_lgbm = lgbm.predict(X_test_enc)

print("LightGBM Accuracy:", accuracy_score(y_test, y_pred_lgbm))
print(classification_report(y_test, y_pred_lgbm))

```

    [LightGBM] [Info] Number of positive: 11504, number of negative: 11504
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.021342 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 13427
    [LightGBM] [Info] Number of data points in the train set: 23008, number of used features: 138
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.500000 -> initscore=0.000000
    LightGBM Accuracy: 0.7987995824634656
                  precision    recall  f1-score   support
    
             0.0       0.87      0.86      0.87      2877
             1.0       0.59      0.61      0.60       955
    
        accuracy                           0.80      3832
       macro avg       0.73      0.74      0.73      3832
    weighted avg       0.80      0.80      0.80      3832
    
    


```python
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

logistic_regression = LogisticRegression(max_iter=1000, random_state=42)
random_forest = RandomForestClassifier(n_estimators=200, random_state=42)
xgboost = XGBClassifier(random_state=42, eval_metric='logloss')
lightgbm = LGBMClassifier(random_state=42)

```


```python
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

models = {
    "Logistic Regression": LogisticRegression(
        max_iter=5000,
        random_state=42
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=200,
        random_state=42
    ),
    "XGBoost": XGBClassifier(
        random_state=42,
        eval_metric='logloss'
    ),
    "LightGBM": LGBMClassifier(
        random_state=42
    )
}

```


```python
from sklearn.linear_model import LogisticRegression

# Train Logistic Regression
log_reg = LogisticRegression(max_iter=1000)
log_reg.fit(X_train_enc, y_train)

```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(max_iter=1000)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;LogisticRegression<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.4/modules/generated/sklearn.linear_model.LogisticRegression.html">?<span>Documentation for LogisticRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>LogisticRegression(max_iter=1000)</pre></div> </div></div></div></div>




```python
models = {
    "Logistic Regression": log_reg,
    "Random Forest": rf,
    "LightGBM": lgbm
}

```


```python
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

results = []

for name, model in models.items():
    model.fit(X_train_sm, y_train_sm)
    y_pred = model.predict(X_test_enc)
    y_prob = model.predict_proba(X_test_enc)[:,1]

    results.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred),
        "Recall": recall_score(y_test, y_pred),
        "F1 Score": f1_score(y_test, y_pred),
        "ROC AUC": roc_auc_score(y_test, y_prob)
    })

```

    [LightGBM] [Info] Number of positive: 11504, number of negative: 11504
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.018289 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 13427
    [LightGBM] [Info] Number of data points in the train set: 23008, number of used features: 138
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.500000 -> initscore=0.000000
    


```python
results_df = pd.DataFrame(results).sort_values(
    by="F1 Score",
    ascending=True
)
results_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
      <th>ROC AUC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Random Forest</td>
      <td>0.785491</td>
      <td>0.579261</td>
      <td>0.508901</td>
      <td>0.541806</td>
      <td>0.805856</td>
    </tr>
    <tr>
      <th>2</th>
      <td>XGBoost</td>
      <td>0.783664</td>
      <td>0.570946</td>
      <td>0.530890</td>
      <td>0.550190</td>
      <td>0.807001</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LightGBM</td>
      <td>0.799843</td>
      <td>0.594949</td>
      <td>0.616754</td>
      <td>0.605656</td>
      <td>0.820582</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Logistic Regression</td>
      <td>0.774791</td>
      <td>0.532857</td>
      <td>0.781152</td>
      <td>0.633546</td>
      <td>0.809932</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(8,5))
sns.barplot(x="ROC AUC", y="Model", data=results_df)
plt.title("Model Comparison (ROC-AUC)")
plt.show()

```


    
![png](output_40_0.png)
    



```python
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Use ENCODED test data
y_pred_lgbm = lgbm.predict(X_test_enc)

cm = confusion_matrix(y_test, y_pred_lgbm)

plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix – LightGBM")
plt.show()

```


    
![png](output_41_0.png)
    



```python
#classfication report
print(classification_report(y_test, y_pred_lgbm))

```

                  precision    recall  f1-score   support
    
             0.0       0.87      0.86      0.87      2877
             1.0       0.59      0.61      0.60       955
    
        accuracy                           0.80      3832
       macro avg       0.73      0.74      0.73      3832
    weighted avg       0.80      0.80      0.80      3832
    
    


```python
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

# Define models (make sure they are already trained/fitted)
models = {
    "Logistic Regression": log_reg,
    "Random Forest": rf,
    "LightGBM": lgbm
}

plt.figure(figsize=(7,5))

for name, model in models.items():
    y_prob = model.predict_proba(X_test_enc)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, label=f"{name} (AUC = {roc_auc:.2f})")

plt.plot([0,1], [0,1], linestyle='--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve Comparison")
plt.legend()
plt.show()

```


    
![png](output_43_0.png)
    



```python
# get feature names after encoding
feature_names = preprocessor.get_feature_names_out()

importance = rf.feature_importances_

imp_df = pd.DataFrame({
    "Feature": feature_names,
    "Importance": importance
}).sort_values(by="Importance", ascending=False)

# plot
plt.figure(figsize=(10,6))
sns.barplot(
    x="Importance",
    y="Feature",
    data=imp_df.head(20)   # top 20 features
)
plt.title("Top 20 Feature Importances - Random Forest")
plt.show()

```


    
![png](output_44_0.png)
    



```python

```
